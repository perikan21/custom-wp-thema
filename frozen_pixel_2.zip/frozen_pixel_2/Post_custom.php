<?php /* Template Name: Post_custom */ ?>
 
<?php get_header(); ?>
 
<div id="primary" class="content-area">

 <div class="container">

  <div class="heder-text-news">
		<h3>News</h3>
		<h1> <span style="font-weight:bold;line-height: 72px;">Keep your focus on the game <br> and stay tuned </span></h1>
  </div>	
  
 <!-- Prvi post --> 
<?php 
$args = array(
'posts_per_page' => 1
);
$query = new WP_query ( $args );
if ( $query->have_posts() ) { ?>

 <div class="container-fluid bg-grey" id="news-top">
	  
	    <div class="row">  
		<?php while ( $query->have_posts() ) : $query->the_post(); ?>
  
 
 
		<article id="post-<?php the_ID(); ?>" <?php post_class( array( 'book', 'left', 'half' ) ); ?>>
  
            <div class="col-sm-8">
                <a href="<?php the_permalink(); ?>">
        			<?php the_post_thumbnail( 'medium', array(
						'class' => 'left',
						'alt'	=> get_the_title()
						) );
					?>
            </div>
		 
      <div class="col-sm-4" id="news-right-post">
                <p><strong style="color: #999;"><?php echo get_the_date(); ?></strong></p>
                <h3><span style="font-weight:bold;line-height: 32px;"><?php the_title(); ?></span></h3>
                <h4>
            <span id="featured-excerpt"><?php the_excerpt(); ?></span>
               </h4>  
           </div>  
				
		    </a>
						
              </div>
				
  		</article>
  
  		<?php endwhile; ?>
  
  		<?php wp_reset_postdata(); ?>
  		
      </div>

  
<?php } ?>
 <!--  / Prvi post --> 

 
  <!-- Ostali postovi --> 
<?php 
$args = array(
'offset' => 1
);
$query = new WP_query ( $args );
if ( $query->have_posts() ) { ?>

<div id="portfolio" class="container-fluid text-center bg-grey">
	
	  <div class="row text-center slideanim">
	
		<?php while ( $query->have_posts() ) : $query->the_post(); ?>

        <div class="col-sm-4">
        <div class="thumbnail">
            
              <a href="<?php the_permalink(); ?>">
    
        			
        	 	<?php the_post_thumbnail( 'medium', array(
						'class' => 'left2',
						'alt'	=> get_the_title()
						) );
					?>		
        			
        <div class="thumbnail-text"> 
        <p style="text-align:left;"><strong><?php echo get_the_date(); ?></strong></p>
        <h6 style="text-align: left;"><?php the_title(); ?></h6>
        </div>	
        </div>
        </div>
	
				
				</a>
	
			
  
  		<?php endwhile; ?>
  
  		<?php wp_reset_postdata(); ?>
 
</div>
   </div>	
<?php } ?>
 </div>	
  <!--  / Ostali postovi --> 


  </div>

 
</div><!-- .content-area -->
 
<?php get_footer(); ?>