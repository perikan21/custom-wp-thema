<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Frozen_Pixel
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	
    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">


	
	<link rel="stylesheet" type="text/css" href="<?php bloginfo("template_directory"); ?>/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php bloginfo("template_directory"); ?>/css/responsive.css" />
	<link rel="stylesheet" type="text/css" href="<?php bloginfo("template_directory"); ?>/css/custom.css" />


	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/custom.js"></script>
	
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <!--[if lt IE 9]>
     <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
     <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	 
	 
   
    <!-- ALL PLUGINS -->
	<script src="js/main.js"></script>
    <script src="js/custom.js"></script>
	
	<script>
function openNav() {
  document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
  document.getElementById("myNav").style.width = "0%";
}
</script>  
  
 
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	
	
 <div class="container-fluid">

    <header class="header">
        <nav class="navbar header-nav navbar-expand-lg">
           <div class="container">
		   
		  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo get_template_directory_uri(); ?>/images/logos/logo-app.png" style="max-width: 150px;"/></a>
		   
				
				<div  class="mobile-menu">
				
					<div id="myNav" class="overlay">
					<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
						<div class="overlay-content">
							<?php
							wp_nav_menu( array(
							'menu_id'        => 'primary-menu') );
							?>	 
						</div>
					</div>

					<span style="font-size:30px;cursor:pointer;float: right;" onclick="openNav()">&#9776;</span>

			 
			    </div>
		
		
				<div  class="heder-menu">	

					<div class="collapse navbar-collapse justify-content-end">
					
					
							<ul class="navbar-nav">
							<?php
							wp_nav_menu( array(
							'menu_id'        => 'primary-menu',
							'menu_class'     => 'navbar-nav',
							) );
							?>	 

							</ul>
					
					</div>
				</div>
		  </div>
        </nav>
		</header>
	
	<div id="content" class="site-content">