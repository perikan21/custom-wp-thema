<?php /* Template Name: Contact */ ?>

<?php
get_header();
?>

<main id="main" class="site-main">
<div class="container">
 <br>
<h3><span style="color:white; float:left;">
    Contact</span> </h3>
 <br>
<h1> <span style="font-weight:bold;line-height: 72px;float:left;text-align:center;">Dont be shy, let us know whats on you mind </span></h1>



  <div class="row" style="width: 100%;padding-top:50px;">
    <div class="col-sm">
     <?php echo do_shortcode( '[contact-form-7 id="115" title="Contact form 1"]' ); ?>
    </div>
    <div class="col-sm">
 <br>
 <br>

<h4><span style="color:white;font-weight:bold;">Email</span> </h4>
<h4><span style="color:white;">
    info @esdsdsds</span> </h4>
<br>

<h4><span style="color:white;font-weight:bold;">Press</span> </h4>
<h4><span style="color:white;">
    info @esdsdsds</span> </h4>
<br>

<h4><span style="color:white;font-weight:bold;">Steam page</span> </h4>
<h4><span style="color:#2565c7;">
    Nanobotic</span> </h4>
<br>
<h4><span style="color:white;font-weight:bold;">Nanopedia</span> </h4>
<h4><span style="color:#2565c7;">
   Nanopedia</span> </h4>
    </div>
  </div>
 </div>
	</div><!-- #primary -->

<?php
get_footer();