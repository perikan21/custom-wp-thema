<?php /* Template Name: Studio */ ?>

<?php
get_header();
?>


<div class="container">

  <div class="heder-text-news" id="news-studio">

		<h3>Frozen Pixel Studio</h3>

		<h1> <span style="font-weight:bold;line-height: 72px;">Independent game <br> development studio </span></h1>
			
  </div>	
   
</div>
	

	<div class="container-fluid">
 		<img src="<?php echo get_template_directory_uri(); ?>/images/allrobots.png" style="width: 100%;"/>
	</div>	
	
	<div class="container" style="text-align: center;padding-top:100px;padding-bottom:100px;">
	  <h2 class="card-text">In the far, distant future, the year 3019, our <br> world has long been taken over and destoyed <br> by Nanobots </h2>
	</div>	
	
	
	
<div class="container-fluid" id="home_container" style="background-color:#2565c7;padding-top:30px;padding-bottom:30px;">
  <div class="container">
    <div class="col-sm-8" style="padding-top: 8%;">
      <h7>About Company Page</h7>
      <h2 style="font-weight:bold;padding-bottom:10px;padding-top:10px">Lorem ipsum. Lorem ipsum  Lorem ipsum <br>    Lorem ipsum Lorem ipsum  Lorem<br>  ipsum Lorem ipsum</h2>
 
     	
   <div class="card3" >
	 <div class="card-body">
	 <h4 class="card-text" style="color:#2565c7; font-weight:bold;">Free to play</h4>
	</div>
	</div>
    </div>
			
	 <div class="flier4" id="robot_right"><img src="<?php echo get_template_directory_uri(); ?>/images/NanoboticRobot.png" "/></div>	
  </div>
</div>


	<div class="container" style="text-align: center;padding-top:100px;padding-bottom:100px;">
	  <h2 class="card-text">In the far, distant future, the year 3019, our <br> world has long been taken over and destoyed <br> by Nanobots </h2>
	</div>	
	
	
<div class="container">
  <div class="text-center">
    <br>
    <br>
  </div>
  <div class="row" style="padding-bottom:50px;">
    <div class="col-sm-4">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
			<img src="<?php echo get_template_directory_uri(); ?>/images/logos/logo.png" style= "float:left; padding-top: 16px;
    padding-bottom: 16px; max-width: 28px;" alt="image">
   
        </div>
        <div class="panel-body" style=" float: left;width: 100%;">
          <h3 style=" float:left;">How it begins</h3>
        </div>
        <div class="panel-footer" style=" float: left;width: 100%;">
          <p style=" float:left;"><strong>50</strong> Lorem</p>
    
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
  			<img src="<?php echo get_template_directory_uri(); ?>/images/logos/logo.png" style= "float:left; padding-top: 16px;
    padding-bottom: 16px; max-width: 28px;" alt="image">
        </div>
        <div class="panel-body" style=" float: left;width: 100%;">
          <h3 style=" float:left;">How it begins</h3>
        </div>
        <div class="panel-footer" style=" float: left;width: 100%;">
          <p style=" float:left;"><strong>50</strong> Lorem</p>
    
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
			<img src="<?php echo get_template_directory_uri(); ?>/images/logos/logo.png" style= "float:left; padding-top: 16px;
    padding-bottom: 16px; max-width: 28px;" alt="image">
        </div>
        <div class="panel-body" style=" float: left;width: 100%;">
          <h3 style=" float:left;">How it begins</h3>
        </div>
        <div class="panel-footer" style=" float: left;width: 100%;">
          <p style=" float:left;"><strong>50</strong> Lorem</p>
    
        </div>
      </div>
    </div>
	
	
  </div>
  

  
</div>	

</div><!-- #primary -->

<?php
get_footer();