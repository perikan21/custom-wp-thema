<?php
get_header();
?>

	<div id="primary" class="content-area">

	 <div class="flier"><img src="<?php echo get_template_directory_uri(); ?>/images/robot.png"/></div>		       
	 <div class="flier2" id="robot_right"><img src="<?php echo get_template_directory_uri(); ?>/images/NanoboticRobot.png"/>	</div>	
		
				
		 <div class="container-fluid">

		  <div class="heder-text-news" id="news-home">

				<h3>Independent game development studio</h3>

				<h1> <span style="font-weight:bold;line-height: 72px;">Nanobotic - first person <br> multiplayer online shooter  <br> battle arena extravaganza </span></h1>
			

					<div class="card"">
						<div class="card-body">
						<a href="./?page_id=107">
						<h4 class="card-text">Free to play</h4>
						</a>
						</div>
					</div>

					
					<div class="card2" >
						<div class="card-body">
						<a href="./?page_id=107">
						<h4 class="card-text">Read more</h4>
						</a>
						</div>
					</div>
					
		  </div>	


	<div class="container-fluid">
	
	
	<img src="<?php echo get_template_directory_uri(); ?>/images/large1.jpg" style="width: 100%;"/>
   
		<div id="header2">	
			<img src="<?php echo get_template_directory_uri(); ?>/images/nanoboticlarge.png" style="width: 100%;"/>
		</div>	
	</div>	
	
	<div class="container" id="header-text2">
	  <h2 class="card-text">In the far, distant future, the year 3019, our <br> world has long been taken over and destoyed <br> by Nanobots </h2>
	</div>	
	
	
	<div class="container"  style="padding-bottom: 150px;">
	  <div class="text-center">
		<br>
		<br>
	  </div>
	  <div class="row" style="padding-bottom:50px;">
		<div class="col-sm-4">
		  <div class="panel panel-default text-center">
			<div class="panel-heading">
			
				<img src="<?php echo get_template_directory_uri(); ?>/images/nanobotic2.png" style= "float:left; padding-top: 16px;
		padding-bottom: 16px; max-width: 32px;" alt="image"/>
			
			</div>
			
			<div class="panel-body" style=" float: left;width: 100%;">
			  <h3 style=" float:left;">How it begins</h3>
			</div>
			
			<div class="panel-footer" style=" float: left;width: 100%;">
			  <p style=" float:left;"><strong>50</strong> Lorem</p>
		
			</div>
		  </div>
		</div>
		
		<div class="col-sm-4">
		  <div class="panel panel-default text-center">
			<div class="panel-heading">
				<img src="<?php echo get_template_directory_uri(); ?>/images/nanobotic2.png" style= "float:left; padding-top: 16px;
		padding-bottom: 16px; max-width: 32px;" alt="image"/>
			</div>
			<div class="panel-body" style=" float: left;width: 100%;">
			  <h3 style=" float:left;">How it begins</h3>
			</div>
			<div class="panel-footer" style=" float: left;width: 100%;">
			  <p style=" float:left;"><strong>50</strong> Lorem</p>
		
			</div>
		  </div>
		</div>
		<div class="col-sm-4">
		  <div class="panel panel-default text-center">
			<div class="panel-heading">
				<img src="<?php echo get_template_directory_uri(); ?>/images/nanobotic2.png" style= "float:left; padding-top: 16px;
		padding-bottom: 16px; max-width: 32px;" alt="image"/>
			</div>
			<div class="panel-body" style=" float: left;width: 100%;">
			  <h3 style=" float:left;">How it begins</h3>
			</div>
			<div class="panel-footer" style=" float: left;width: 100%;">
			  <p style=" float:left;"><strong>50</strong> Lorem</p>
		
			</div>
		  </div>
		</div>
		
		
	  </div>
	  
	   <div class="card" style="float:right; padding-bottom:20px;">
		 <div class="card-body">
		 <h4 class="card-text">Free to play</h4>
		</div>
		</div>

	</div>	
	
	
	<div class="container-fluid" id="home_container" style="background-color:#2565c7;padding-top:30px;padding-bottom:30px;">
	  <div class="container">
		<div class="col-sm-8" style="padding-top: 8%;">
			  <h7>About Company Page</h7>
			  <h2 style="font-weight:bold;padding-bottom:10px;padding-top:10px">Lorem ipsum. Lorem ipsum  Lorem ipsum <br>    Lorem ipsum Lorem ipsum  Lorem<br>  ipsum Lorem ipsum</h2>
		 
				
		   <div class="card3" >
			 <div class="card-body">
			  <h4 class="card-text" style="color:#2565c7; font-weight:bold;">Free to play</h4>
			 </div>
			</div>
		</div>

	  </div>
	</div>


	</div><!-- #primary -->

<?php
get_footer();