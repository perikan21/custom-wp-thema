<?php get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

 <div class="container" style="padding-top:100px;">

  	 	<?php the_post_thumbnail( 'full', array(
						'class' => 'left',
						'alt'	=> get_the_title()
						) );
					?>		
			
  </div>	
   
</div>
	
 <div class="container">

  <div class="heder-text-news" id="news-home1">


		<h1> <span style="font-weight:bold;line-height: 72px;"><?php the_title(); ?> </span></h1>
		
		<p> <?php echo get_the_date(); ?></p>
		<h3> <?php the_content(); ?></h3>		
  </div>	
   
</div>


<?php endwhile; ?>
<?php endif; ?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>