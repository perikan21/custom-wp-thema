<?php /* Template Name: Nanobotic */ ?>

<?php
get_header();
?>

	<div id="primary" class="content-area">
	 <div class="flier"><img src="<?php echo get_template_directory_uri(); ?>/images/robot.png"/></div>		        
	 <div class="flier3" id="robot_right"><img src="<?php echo get_template_directory_uri(); ?>/images/gun.png"/>	</div>	
		
  		
		 <div class="container">

		  <div class="heder-text-news" id="news-studio">
			  
		   <h3>Independent game development studio</h3>

			 <h1> <span style="font-weight:bold;line-height: 72px;">Nanobotic - first person <br> multiplayer online shooter  <br> battle arena extravaganza </span></h1>
					
		  </div>	
		   
		</div>		
		
	
	<div class="container-fluid">
		<div id="nanobotic">		
		 <img src="<?php echo get_template_directory_uri(); ?>/images/nanoboticnontransparent.png" style="width: 100%;"/>
		</div>
		
		<br>
		<br>
		<img src="<?php echo get_template_directory_uri(); ?>/images/largerobot.png" style="width: 100%;"/>
	</div>
	
	 <div class="container">
	  <div style="padding-top:100px;padding-bottom:100px;">
	   <?php echo do_shortcode('[slide-anything id="235"]'); ?>  					
	  </div>	
	</div>	
	
	<div class="container-fluid">	
   	 <img src="<?php echo get_template_directory_uri(); ?>/images/largeimg.png" style="width: 100%;"/>	 		
	</div>
	
	<div class="container" style="text-align: center;">
		<br>
		<br>
	  <h1> <span style="font-weight:bold;line-height: 72px;">Nanobotic Gameplay </span></h1>
	  	<br>
		<br>
	</div>	
	
<div class="container"  style="padding-bottom: 150px;">
  <div class="text-center">
    <br>
    <br>
  </div>
  <div class="row" style="padding-bottom:50px;">
    <div class="col-sm-4">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
	 	<img src="<?php echo get_template_directory_uri(); ?>/images/nanobotic2.png" style= "float:left; padding-top: 16px;
    padding-bottom: 16px; max-width: 32px;" alt="image">
    
        </div>
        <div class="panel-body" style=" float: left;width: 100%;">
          <h3 style=" float:left;">How it begins</h3>
        </div>
        <div class="panel-footer" style=" float: left;width: 100%;">
          <p style=" float:left;"><strong>50</strong> Lorem</p>
    
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
 	<img src="<?php echo get_template_directory_uri(); ?>/images/nanobotic2.png" style= "float:left; padding-top: 16px;
    padding-bottom: 16px; max-width: 32px;" alt="image">
        </div>
        <div class="panel-body" style=" float: left;width: 100%;">
          <h3 style=" float:left;">How it begins</h3>
        </div>
        <div class="panel-footer" style=" float: left;width: 100%;">
          <p style=" float:left;"><strong>50</strong> Lorem</p>
    
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
     	<img src="<?php echo get_template_directory_uri(); ?>/images/nanobotic2.png" style= "float:left; padding-top: 16px;
    padding-bottom: 16px; max-width: 32px;" alt="image">
        </div>
        <div class="panel-body" style=" float: left;width: 100%;">
          <h3 style=" float:left;">How it begins</h3>
        </div>
        <div class="panel-footer" style=" float: left;width: 100%;">
          <p style=" float:left;"><strong>50</strong> Lorem</p>
    
        </div>
      </div>
    </div>
	<br>
	
   <div class="col-sm-4">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
  	<img src="<?php echo get_template_directory_uri(); ?>/images/nanobotic2.png" style= "float:left; padding-top: 16px;
    padding-bottom: 16px; max-width: 32px;" alt="image">
        </div>
        <div class="panel-body" style=" float: left;width: 100%;">
          <h3 style=" float:left;">How it begins</h3>
        </div>
        <div class="panel-footer" style=" float: left;width: 100%;">
          <p style=" float:left;"><strong>50</strong> Lorem</p>
    
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
    	<img src="<?php echo get_template_directory_uri(); ?>/images/nanobotic2.png" style= "float:left; padding-top: 16px;
    padding-bottom: 16px; max-width: 32px;" alt="image">
        </div>
        <div class="panel-body" style=" float: left;width: 100%;">
          <h3 style=" float:left;">How it begins</h3>
        </div>
        <div class="panel-footer" style=" float: left;width: 100%;">
          <p style=" float:left;"><strong>50</strong> Lorem</p>
    
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="panel panel-default text-center">
        <div class="panel-heading">
     	<img src="<?php echo get_template_directory_uri(); ?>/images/nanobotic2.png" style= "float:left; padding-top: 16px;
    padding-bottom: 16px; max-width: 32px;" alt="image">
        </div>
        <div class="panel-body" style=" float: left;width: 100%;">
          <h3 style=" float:left;">How it begins</h3>
        </div>
        <div class="panel-footer" style=" float: left;width: 100%;">
          <p style=" float:left;"><strong>50</strong> Lorem</p>
    
        </div>
      </div>
    </div>
	
  </div>
  

  
</div>	
		
	<div class="container-fluid">
	   	<img src="<?php echo get_template_directory_uri(); ?>/images/largeimg2.png" style="width: 100%;"/>	 	
	</div>
	
	<div class="container" style="padding-top:100px;">
    	<?php echo do_shortcode('[ctu_ultimate_oxi  id="1"]'); ?>
	</div>
             
</div>

	</div><!-- #primary -->

<?php
get_footer();