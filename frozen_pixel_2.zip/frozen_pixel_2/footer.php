<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Frozen_Pixel
 */

?>

	</div><!-- #content -->


		<!-- Footer -->
		<footer class="page-footer font-small unique-color-dark">

		  <div>
			<div class="container">

			  <!-- Grid row-->
			  <div class="row py-4 d-flex align-items-center">

				<!-- Grid column -->
				<div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
			    <img src="<?php echo get_template_directory_uri(); ?>/images/logos/logo.png" style="max-width: 28px;"/>
				</div>
				<!-- Grid column -->

				<!-- Grid column -->
				<div class="col-md-6 col-lg-7 text-center text-md-right">

				  <!-- Facebook -->
				  <a class="fb-ic">
					<i class="fab fa-youtube white-text mr-4" style='font-size: 16px !important;color: white;'> </i>
				  </a>
				  <!-- Twitter -->
				  <a class="tw-ic">
					<i class="fab fa-twitter white-text mr-4" style='font-size: 16px !important;color: white;'> </i>
				  </a>
				  <!-- Google +-->
				  <a class="gplus-ic">
					<i class="fab fa-google-plus-g white-text mr-4" style='font-size: 16px !important;color: white;'> </i>
				  </a>

				  <!--Instagram-->
				  <a class="ins-ic">
					<i class="fab fa-instagram white-text" style='font-size: 16px !important;color: white;'> </i>
				  </a>

				</div>
				<!-- Grid column -->


			  </div>
			  <!-- Grid row-->

			</div>
		  </div>

		</footer>
		<!-- Footer -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
